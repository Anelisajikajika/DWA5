// scripts.js

document.addEventListener('DOMContentLoaded', (event) => {
  const resultDiv = document.getElementById('result');
  const submitButton = document.getElementById('submit');

  submitButton.addEventListener('click', () => {
      const input1 = document.getElementById('input1').value.trim();
      const input2 = document.getElementById('input2').value.trim();

      try {
          if (!input1 || !input2) {
              resultDiv.innerText = 'Division not performed. Both values are required in inputs. Try again';
              return;
          }

          const num1 = parseFloat(input1);
          const num2 = parseFloat(input2);

          if (isNaN(num1) || isNaN(num2)) {
              throw new Error('Non-numeric input');
          }

          if (num2 === 0) {
              resultDiv.innerText = 'Division not performed. Invalid number provided. Try again';
              console.error('Invalid division by zero', new Error().stack);
              return;
          }

          const result = num1 / num2;

          if (!Number.isFinite(result)) {
              resultDiv.innerText = 'Division not performed. Invalid number provided. Try again';
              console.error('Invalid division', new Error().stack);
              return;
          }

          resultDiv.innerText = result.toFixed(2);  // Display result rounded to 2 decimal places

      } catch (error) {
          console.error('Critical error occurred', error.stack);
          resultDiv.innerText = 'Something critical went wrong. Please reload the page';
      }
  });
});
